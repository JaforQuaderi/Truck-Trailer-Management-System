/// Project Name- "Truck-Trailer Management System"
/// Submitted By- "Shah Jafor Sadeek Quaderi >>> CSE-107 >>> Section - 5"
/// ID-"2014-2-60-075"
/// Reference- This Project Successfully Compiled On Jafor's PC & Fahim PC in Visual Stdio 2013

#include<iostream>
#include<istream>
#include<cstdio>
#include<cstring>

#define NameLength 40   // Defining Name Length of Customer
#define AddressLength 100   // Define Address Length of Customer

using namespace std;

class Platinum_Ion
{
public:
    friend ostream& operator << (ostream& print, const Platinum_Ion &pltin) // Operator Overloading
    {
    print << "\n    **********************************************************************     \n" << endl;
    print << "Platinum-Ion Trailer Service Dhaka is a branch of ETS (Euro Truck Simulator). ";
    print << "  Euro Truck Simulator which is popular and best trailer service in European      countries. ";
    print << "Its the ultra modern trailer system around the world and this system is  established first in Bangladesh. ";
    print << "In this garage people can rent trucks for  trailer. ";
    print << "This management system ensures you all kinds of security. We try to    provide best facilities to our customer.\n"<< endl;
    print << "Our facilities and services:-\n\n"<< endl;
    print << "* World class trucks. \n"<< endl;
    print << "* Experienced Drivers.\n"<< endl;
    print << "* Computerized process.\n"<< endl;
    print << "* Fastest transport system around the Bangladesh. .\n "<< endl;
    print << "* 365 days transport system.\n"<< endl;
    print << "* No extra charge for employees & fuel.\n "<< endl;
    print << "* Guarantee for full pay in case of accident.\n"<< endl;
    return print;
    }
};

class Trailer_List
{
private:
    float trailerPrice;
public:
    Trailer_List()  // No Argument Constructor of Trailer_Info Class
    {}
    void showTrailerList()  // Showing Trailer List
    {
        static int i=0;  // Use Static for Counting
        cout << "\n    **********************************************************************     \n" << endl;
        cout <<" "<< ++i <<". Ammunition          - 28.00 tk/km" << endl;
        cout <<" "<< ++i <<". Bamboo              - 19.00 tk/km" << endl;
        cout <<" "<< ++i <<". Cement              - 21.00 tk/km" << endl;
        cout <<" "<< ++i <<". Chemical            - 28.00 tk/km" << endl;
        cout <<" "<< ++i <<". Cloth               - 18.00 tk/km" << endl;
        cout <<" "<< ++i <<". Coal                - 25.00 tk/km" << endl;
        cout <<" "<< ++i <<". Crops               - 20.00 tk/km" << endl;
        cout <<" "<< ++i <<". Digger              - 27.00 tk/km" << endl;
        cout <<" "<< ++i <<". Dry-Milk            - 22.00 tk/km" << endl;
        cout << ++i <<". Electronics-Parts   - 18.00 tk/km" << endl;
        cout << ++i <<". Excavator           - 31.00 tk/km" << endl;
        cout << ++i <<". Fish                - 25.00 tk/km" << endl;
        cout << ++i <<". Flowers             - 21.00 tk/km" << endl;
        cout << ++i <<". Food                - 20.00 tk/km" << endl;
        cout << ++i <<". Frozen-Food         - 23.00 tk/km" << endl;
        cout << ++i <<". Fruits              - 24.00 tk/km" << endl;
        cout << ++i <<". Furniture           - 23.00 tk/km" << endl;
        cout << ++i <<". Gas                 - 25.00 tk/km" << endl;
        cout << ++i <<". Glass               - 21.00 tk/km" << endl;
        cout << ++i <<". Ice-Cream           - 29.00 tk/km" << endl;
        cout << ++i <<". Iron                - 28.00 tk/km" << endl;
        cout << ++i <<". Liquid-Oxygen       - 30.00 tk/km" << endl;
        cout << ++i <<". Meat                - 25.00 tk/km" << endl;
        cout << ++i <<". Medical-Accessories - 30.00 tk/km" << endl;
        cout << ++i <<". Metal               - 28.00 tk/km" << endl;
        cout << ++i <<". Oil                 - 24.00 tk/km" << endl;
        cout << ++i <<". Petroleum           - 23.00 tk/km" << endl;
        cout << ++i <<". Rock                - 25.00 tk/km" << endl;
        cout << ++i <<". Sand                - 22.00 tk/km" << endl;
        cout << ++i <<". Spices              - 19.00 tk/km" << endl;
        cout << ++i <<". Tractor             - 28.00 tk/km" << endl;
        cout << ++i <<". Vegetables          - 23.00 tk/km" << endl;
        cout << ++i <<". Water               - 21.00 tk/km" << endl;
        cout << ++i <<". Wood                - 20.00 tk/km" << endl;
        cout << "\n    **********************************************************************     \n" << endl;
        i = 0;
    }
    void showAmmunition()
    {
        cout << "You have chosen :-  Ammunition _ which is cost: 28 tk/km" << endl;
        trailerPrice = 28.00;
    }
    void showBamboo()
    {
        cout << "You have chosen :- Bamboo _ which is cost: 13 tk/km" << endl;
        trailerPrice = 13.00;
    }
    void showCement()
    {
        cout << "You have chosen :- Cement _ which is cost: 16 tk/km" << endl;
        trailerPrice = 16.00;
    }
    void showChemical()
    {
        cout << "You have chosen :- Chemical _ which is cost: 22.00 tk/km" << endl;
        trailerPrice = 22.00;
    }
    void showCloth()
    {
        cout << "You have chosen :- Cloth _ which is cost: 14.00 tk/km" << endl;
        trailerPrice = 14.00;
    }
    void showCoal()
    {
        cout << "You have chosen :- Coal _ which is cost: 20.00 tk/km" << endl;
        trailerPrice = 20.00;
    }
    void showCrops()
    {
        cout << "You have chosen :- Crops _ which is cost: 15.00 tk/km" << endl;
        trailerPrice = 25.00;
    }
    void showDigger()
    {
        cout << "You have chosen :- Digger _ which is cost: 27.00 tk/km" << endl;
        trailerPrice = 27.00;
    }
    void showDry_Milk()
    {
        cout << "You have chosen :- Dry-Mil _ which is cost: 22.00 tk/km" << endl;
        trailerPrice = 17.00;
    }
    void showElectronics_Parts()
    {
        cout << "You have chosen :- Electronics-Parts _ which is cost: 18.00 tk/km" << endl;
        trailerPrice = 18.00;
    }
    void showExcavator()
    {
        cout << "You have chosen :- Excavator _ which is cost: 26.00 tk/km" << endl;
        trailerPrice = 26.00;
    }
    void showFish()
    {
        cout << "You have chosen :- Fish _ which is cost: 20.00 tk/km" << endl;
        trailerPrice = 20.00;
    }
    void showFlowers()
    {
        cout << "You have chosen :- Flowers _ which is cost: 16.00 tk/km" << endl;
        trailerPrice = 16.00;
    }
    void showFood()
    {
        cout << "You have chosen :- Food _ which is cost: 15.00 tk/km" << endl;
        trailerPrice = 15.00;
    }
    void showFrozen_Food()
    {
        cout << "You have chosen :- Frozen-Food _ which is cost: 18.00 tk/km" << endl;
        trailerPrice = 18.00;
    }
    void showFruits()
    {
        cout << "You have chosen :- Fruits _ which is cost: 19.00 tk/km" << endl;
        trailerPrice = 19.00;
    }
    void showFurniture()
    {
        cout << "You have chosen :- Furniture _ which is cost: 20.00 tk/km" << endl;
        trailerPrice = 20.00;
    }
    void showGas()
    {
        cout << "You have chosen :- Gas _ which is cost: 18.00 tk/km" << endl;
        trailerPrice = 18.00;
    }
    void showGlass()
    {
        cout << "You have chosen :- Glass _ which is cost: 17.00 tk/km" << endl;
        trailerPrice = 17.00;
    }
    void showIce_Cream()
    {
        cout << "You have chosen :- Ice-Cream _ which is cost: 23.00 tk/km" << endl;
        trailerPrice = 23.00;
    }
    void showIron()
    {
        cout << "You have chosen :- Iron _ which is cost: 24.00 tk/km" << endl;
        trailerPrice = 24.00;
    }
    void showLiquid_Oxygen()
    {
        cout << "You have chosen :- Liquid-Oxygen _ which is cost: 23 tk/km" << endl;
        trailerPrice = 23;
    }
    void showMeat()
    {
        cout << "You have chosen :- Meat _ which is cost: 20.00 tk/km" << endl;
        trailerPrice = 20.00;
    }
    void showMedical_Accessories()
    {
        cout << "You have chosen :- Medical-Accessories _ which is cost: 23.00 tk/km" << endl;
        trailerPrice = 23.00;
    }
    void showMetal()
    {
        cout << "You have chosen :- Metal _ which is cost: 24.00 tk/km" << endl;
        trailerPrice = 24.00;
    }
    void showOil()
    {
        cout << "You have chosen :- Oil _ which is cost: 20.00 tk/km" << endl;
        trailerPrice = 20.00;
    }
    void showPetroleum()
    {
        cout << "You have chosen :-Petroleum  _ which is cost: 18.00 tk/km" << endl;
        trailerPrice = 18.00;
    }
    void showRock()
    {
        cout << "You have chosen :- Rock _ which is cost: 20.00 tk/km" << endl;
        trailerPrice = 20.00;
    }
    void showSand()
    {
        cout << "You have chosen :- Sand _ which is cost: 17.00 tk/km" << endl;
        trailerPrice = 17.00;
    }
    void showSpices()
    {
        cout << "You have chosen :- Spices _ which is cost: 14.00 tk/km" << endl;
        trailerPrice = 14.00;
    }
    void showTractor()
    {
        cout << "You have chosen :- Tractor _ which is cost: 22.00 tk/km" << endl;
        trailerPrice = 22.00;
    }
    void showVegetables()
    {
        cout << "You have chosen :- Vegetables _ which is cost: 19.00 tk/km" << endl;
        trailerPrice = 19.00;
    }
    void showWater()
    {
        cout << "You have chosen :- Water _ which is cost: 15.00 tk/km" << endl;
        trailerPrice = 15.00;
    }
    void showWood()
    {
        cout << "You have chosen :- Wood _ which is cost: 18.00 tk/km" << endl;
        trailerPrice = 18.00;
    }
    void showWrongInput()
    {
        cout << "You have pressed wrong input... Please Choose Right Option" << endl;
    }
    void setTrailerPrice(float trailerprice)
    {
        trailerPrice = trailerprice;
    }
    float getTrailerPrice()
    {
        return trailerPrice;
    }
    ~Trailer_List()  // Distructor of Trailer_Info Class
    {
        cout << "Trailer_Info Constructor Has Distructred" << endl;
    }
};

class Route
{
protected:  // Use Protected for Multiple Inheritance
    float routePrice;
public:
    void showRouteList()  // Showing Routes List
    {
        static int i;
        cout << "\n    **********************************************************************     \n" << endl;
        cout <<" "<< ++i << ". Dhaka - Bagerhat... ...Distance- 177 km" << endl;
        cout <<" "<< ++i << ". Dhaka - Bandarban......Distance- 411 km" << endl;
        cout <<" "<< ++i << ". Dhaka - Barguna........Distance- 306 km" << endl;
        cout <<" "<< ++i << ". Dhaka - Barisal... ....Distance- 235 km" << endl;
        cout <<" "<< ++i << ". Dhaka - Barnmanbaria...Distance-  96 km" << endl;
        cout <<" "<< ++i << ". Dhaka - Bhola..........Distance- 252 km" << endl;
        cout <<" "<< ++i << ". Dhaka - Bogra... ......Distance- 193 km" << endl;
        cout <<" "<< ++i << ". Dhaka - Chandpur.......Distance- 112 km" << endl;
        cout <<" "<< ++i << ". Dhaka - Chittagong.....Distance- 252 km" << endl;
        cout << ++i << ". Dhaka - Chuadanga......Distance- 286 km" << endl;
        cout << ++i << ". Dhaka - Comilla........Distance- 106 km" << endl;
        cout << ++i << ". Dhaka - Cox's Bazar....Distance- 398 km" << endl;
        cout << ++i << ". Dhaka - Dinajpur.......Distance- 352 km" << endl;
        cout << ++i << ". Dhaka - Faridpur.......Distance- 138 km" << endl;
        cout << ++i << ". Dhaka - Feni...........Distance- 167 km" << endl;
        cout << ++i << ". Dhaka - Gaibandha......Distance- 240 km" << endl;
        cout << ++i << ". Dhaka - Gazipur........Distance-  43 km" << endl;
        cout << ++i << ". Dhaka - Gopalganj......Distance- 201 km" << endl;
        cout << ++i << ". Dhaka - Habiganj.......Distance- 163 km" << endl;
        cout << ++i << ". Dhaka - Jaipurhat......Distance- 253 km" << endl;
        cout << ++i << ". Dhaka - Jamalpur.......Distance- 192 km" << endl;
        cout << ++i << ". Dhaka - Jessore........Distance- 226 km" << endl;
        cout << ++i << ". Dhaka - Jhalakathi.....Distance- 260 km" << endl;
        cout << ++i << ". Dhaka - Jhinaidah......Distance- 218 km" << endl;
        cout << ++i << ". Dhaka - Khagrachari....Distance- 271 km" << endl;
        cout << ++i << ". Dhaka - Khulna.........Distance- 269 km" << endl;
        cout << ++i << ". Dhaka - Kishoreganj....Distance-  89 km" << endl;
        cout << ++i << ". Dhaka - Kurigram.......Distance- 350 km" << endl;
        cout << ++i << ". Dhaka - Kushtia........Distance- 247 km" << endl;
        cout << ++i << ". Dhaka - Lakshmipur.....Distance- 155 km" << endl;
        cout << ++i << ". Dhaka - Lalmonirhat....Distance- 365 km" << endl;
        cout << ++i << ". Dhaka - Madaripur......Distance-  67 km" << endl;
        cout << ++i << ". Dhaka - Magura.........Distance- 175 km" << endl;
        cout << ++i << ". Dhaka - Manikganj......Distance-  69 km" << endl;
        cout << ++i << ". Dhaka - Meherpur.......Distance- 277 km" << endl;
        cout << ++i << ". Dhaka - Moulavibazar...Distance- 192 km" << endl;
        cout << ++i << ". Dhaka - Munshiganj.....Distance-  44 km" << endl;
        cout << ++i << ". Dhaka - Mymensingh.....Distance- 119 km" << endl;
        cout << ++i << ". Dhaka - Naogaon........Distance- 283 km" << endl;
        cout << ++i << ". Dhaka - Narayangan.....Distance-  28 km" << endl;
        cout << ++i << ". Dhaka - Narsingdi .....Distance-  44 km" << endl;
        cout << ++i << ". Dhaka - Natore.........Distance- 196 km" << endl;
        cout << ++i << ". Dhaka - Nawabgonj......Distance-  50 km" << endl;
        cout << ++i << ". Dhaka - Netrokona......Distance- 170 km" << endl;
        cout << ++i << ". Dhaka - Nilphamari ....Distance- 347 km" << endl;
        cout << ++i << ". Dhaka - Noakhali.......Distance- 214 km" << endl;
        cout << ++i << ". Dhaka - Norail.........Distance- 220 km" << endl;
        cout << ++i << ". Dhaka - Pabna..........Distance- 200 km" << endl;
        cout << ++i << ". Dhaka - Panchagarh.....Distance- 404 km" << endl;
        cout << ++i << ". Dhaka - Patuakhali.....Distance- 207 km" << endl;
        cout << ++i << ". Dhaka - Pirojpur.......Distance- 133 km" << endl;
        cout << ++i << ". Dhaka - Rajbari........Distance- 121 km" << endl;
        cout << ++i << ". Dhaka - Rajshahi.......Distance- 241 km" << endl;
        cout << ++i << ". Dhaka - Rangamati......Distance- 302 km" << endl;
        cout << ++i << ". Dhaka - Rangpur........Distance- 279 km" << endl;
        cout << ++i << ". Dhaka - Satkhira.......Distance- 243 km" << endl;
        cout << ++i << ". Dhaka - Shariyatpur....Distance-  99 km" << endl;
        cout << ++i << ". Dhaka - Sherpur........Distance- 143 km" << endl;
        cout << ++i << ". Dhaka - Sirajgonj......Distance- 127 km" << endl;
        cout << ++i << ". Dhaka - Sunamganj......Distance- 159 km" << endl;
        cout << ++i << ". Dhaka - Sylhet.........Distance- 238 km" << endl;
        cout << ++i << ". Dhaka - Tangail........Distance-  84 km" << endl;
        cout << ++i << ". Dhaka - Thakurgaon.....Distance- 389 km" << endl;
        cout << "\n    **********************************************************************     \n" << endl;
        i = 0;
    }
    void route_Dh_to_Brgrht()
    {
        cout << "Your selected route: Dhaka - Bagerhat, Route Length: 177 km" << endl;
        routePrice = 177;
    }
    void route_Dh_to_Bndrbn()
    {
        cout << "Your selected route: Dhaka - Bandarban, Route Length: 411 km" << endl;
        routePrice = 411;
    }

    void route_Dh_to_Brgn()
    {
        cout << "Your selected route: Dhaka - Barguna, Route Length: 306 km" << endl;
        routePrice = 306;
    }
    void route_Dh_to_Brshl()
    {
        cout << "Your selected route: Dhaka - Barisal, Route Length: 235 km" << endl;
        routePrice = 235;
    }
    void route_Dh_to_Brnmnbr()
    {
        cout << "Your selected route: Dhaka - Branmanbaria, Route Length: 96 km" << endl;
        routePrice = 96;
    }
    void route_Dh_to_Bhl()
    {
        cout << "Your selected route: Dhaka - Bhola, Route Length: 252 km" << endl;
        routePrice = 252;
    }
    void route_Dh_to_Bgr()
    {
        cout << "Your selected route: Dhaka - Bogra, Route Length: 193 km" << endl;
        routePrice = 193;
    }
    void route_Dh_to_Chndpr()
    {
        cout << "Your selected route: Dhaka - Chandpur, Route Length: 112 km" << endl;
        routePrice = 112;
    }
    void route_Dh_to_Chttgng()
    {
        cout << "Your selected route: Dhaka - Chittagong, Route Length: 252 km" << endl;
        routePrice = 252;
    }
    void route_Dh_to_Chdng()
    {
        cout << "Your selected route: Dhaka - Chuadanga, Route Length: 286 km" << endl;
        routePrice = 286;
    }
    void route_Dh_to_Cmll()
    {
        cout << "Your selected route: Dhaka - Comilla, Route Length: 106 km" << endl;
        routePrice = 106;
    }
    void route_Dh_to_Cxbzr()
    {
        cout << "Your selected route: Dhaka - Cox's Bazar, Route Length: 398 km" << endl;
        routePrice = 398;
    }
    void route_Dh_to_Dnjpr()
    {
        cout << "Your selected route: Dhaka - Dinajpur, Route Length: 352 km" << endl;
        routePrice = 352;
    }
    void route_Dh_to_Frdpr()
    {
        cout << "Your selected route: Dhaka - Faridpur, Route Length: 138 km" << endl;
        routePrice = 138;
    }
    void route_Dh_to_Fn()
    {
        cout << "Your selected route: Dhaka - Feni, Route Length: 167 km" << endl;
        routePrice = 167;
    }
    void route_Dh_to_Gnbndh()
    {
        cout << "Your selected route: Dhaka - Gaibandha, Route Length: 240 km" << endl;
        routePrice = 240;
    }
    void route_Dh_to_Gzpr()
    {
        cout << "Your selected route: Dhaka - Gazipur, Route Length: 43 km" << endl;
        routePrice = 43;
    }
    void route_Dh_to_Gplgnj()
    {
        cout << "Your selected route: Dhaka - Gopalganj, Route Length: 201 km" << endl;
        routePrice = 201;
    }
    void route_Dh_to_Hbgnj()
    {
        cout << "Your selected route: Dhaka - Habiganj, Route Length: 163 km" << endl;
        routePrice = 163;
    }
    void route_Dh_to_Jprht()
    {
        cout << "Your selected route: Dhaka - Jaipurhat, Route Length: 253 km" << endl;
        routePrice = 253;
    }
    void route_Dh_to_Jmlpr()
    {
        cout << "Your selected route: Dhaka - Jamalpur, Route Length: 192 km" << endl;
        routePrice = 192;
    }
    void route_Dh_to_Jssr()
    {
        cout << "Your selected route: Dhaka - Jessore, Route Length: 226 km" << endl;
        routePrice = 226;
    }
    void route_Dh_to_Jhlkth()
    {
        cout << "Your selected route: Dhaka - Jhalakathi, Route Length: 260 km" << endl;
        routePrice = 260;
    }
    void route_Dh_to_Jhndh()
    {
        cout << "Your selected route: Dhaka - Jhinaidah, Route Length: 218 km" << endl;
        routePrice = 218;
    }
    void route_Dh_to_Khgrchr()
    {
        cout << "Your selected route: Dhaka - Khagrachari, Route Length: 271 km" << endl;
        routePrice = 271;
    }
    void route_Dh_to_Khln()
    {
        cout << "Your selected route: Dhaka Khulna- , Route Length: 269 km" << endl;
        routePrice = 269;
    }
    void route_Dh_to_Kshrgnj()
    {
        cout << "Your selected route: Dhaka - Kishoreganj, Route Length: 89 km" << endl;
        routePrice = 89;
    }
    void route_Dh_to_Krgrm()
    {
        cout << "Your selected route: Dhaka - Kurigram, Route Length: 350 km" << endl;
        routePrice = 350;
    }
    void route_Dh_to_Ksht()
    {
        cout << "Your selected route: Dhaka - Kushtia, Route Length: 247 km" << endl;
        routePrice = 247;
    }
    void route_Dh_to_Lkshmpr()
    {
        cout << "Your selected route: Dhaka - Lakshmipur, Route Length: 155 km" << endl;
        routePrice = 155;
    }
    void route_Dh_to_Llmnrht()
    {
        cout << "Your selected route: Dhaka - Lalmonirhat, Route Length: 365 km" << endl;
        routePrice = 365;
    }
    void route_Dh_to_Mdrpr()
    {
        cout << "Your selected route: Dhaka - Madaripur, Route Length: 67 km" << endl;
        routePrice = 67;
    }
    void route_Dh_to_Mgr()
    {
        cout << "Your selected route: Dhaka - Magura, Route Length: 175 km" << endl;
        routePrice = 175;
    }
    void route_Dh_to_Mnkgnj()
    {
        cout << "Your selected route: Dhaka - Manikganj, Route Length: 69 km" << endl;
        routePrice = 69;
    }
    void route_Dh_to_Mhrpr()
    {
        cout << "Your selected route: Dhaka - Meherpur, Route Length: 277 km" << endl;
        routePrice = 277;
    }
    void route_Dh_to_Mulvbzr()
    {
        cout << "Your selected route: Dhaka - Moulavibazar, Route Length: 192 km" << endl;
        routePrice = 192;
    }
    void route_Dh_to_Mnshgnj()
    {
        cout << "Your selected route: Dhaka - Munshiganj, Route Length: 44 km" << endl;
        routePrice = 44;
    }
    void route_Dh_to_Mymnsngh()
    {
        cout << "Your selected route: Dhaka - Mymensingh, Route Length: 119 km" << endl;
        routePrice = 119;
    }
    void route_Dh_to_Ngn()
    {
        cout << "Your selected route: Dhaka - Naogaon, Route Length: 283 km" << endl;
        routePrice = 283;
    }
    void route_Dh_to_Nryngn()
    {
        cout << "Your selected route: Dhaka - Narayangan, Route Length:28  km" << endl;
        routePrice = 28;
    }
    void route_Dh_to_Nrsngd()
    {
        cout << "Your selected route: Dhaka - Narsingdi, Route Length: 44 km" << endl;
        routePrice = 44;
    }
    void route_Dh_to_Ntr()
    {
        cout << "Your selected route: Dhaka - Natore, Route Length: 196 km" << endl;
        routePrice = 196;
    }
    void route_Dh_to_Nwbgnj()
    {
        cout << "Your selected route: Dhaka - Nawabgonj, Route Length: 50 km" << endl;
        routePrice = 50;
    }
    void route_Dh_to_Ntrkn()
    {
        cout << "Your selected route: Dhaka - Netrokona, Route Length: 170 km" << endl;
        routePrice = 170;
    }
    void route_Dh_to_Nlphmar()
    {
        cout << "Your selected route: Dhaka - Nilphamari, Route Length: 347 km" << endl;
        routePrice = 347;
    }
    void route_Dh_to_Nkhl()
    {
        cout << "Your selected route: Dhaka - Noakhali, Route Length: 214 km" << endl;
        routePrice = 214;
    }
    void route_Dh_to_Nrl()
    {
        cout << "Your selected route: Dhaka - Norail, Route Length: 220 km" << endl;
        routePrice = 220;
    }
    void route_Dh_to_Pbn()
    {
        cout << "Your selected route: Dhaka - Pabna, Route Length: 200 km" << endl;
        routePrice = 200;
    }
    void route_Dh_to_Pnchgrh()
    {
        cout << "Your selected route: Dhaka - Panchagarh, Route Length: 404 km" << endl;
        routePrice = 404;
    }
    void route_Dh_to_Ptkhl()
    {
        cout << "Your selected route: Dhaka - Patuakhali, Route Length: 207 km" << endl;
        routePrice = 207;
    }
    void route_Dh_to_Prjpr()
    {
        cout << "Your selected route: Dhaka - Pirojpur, Route Length: 133 km" << endl;
        routePrice = 133;
    }
    void route_Dh_to_Rjbr()
    {
        cout << "Your selected route: Dhaka - Rajbari, Route Length: 121 km" << endl;
        routePrice = 121;
    }
    void route_Dh_to_Rjshh()
    {
        cout << "Your selected route: Dhaka - Rajshahi, Route Length: 241 km" << endl;
        routePrice = 241;
    }
    void route_Dh_to_Rngmt()
    {
        cout << "Your selected route: Dhaka - Rangamati, Route Length: 302 km" << endl;
        routePrice = 302;
    }
    void route_Dh_to_Rngpr()
    {
        cout << "Your selected route: Dhaka - Rangpur, Route Length: 279 km" << endl;
        routePrice = 279;
    }
    void route_Dh_to_Stkhr()
    {
        cout << "Your selected route: Dhaka - Satkhira, Route Length: 243 km" << endl;
        routePrice = 243;
    }
    void route_Dh_to_Shrytpr()
    {
        cout << "Your selected route: Dhaka - Shariyatpur, Route Length: 99 km" << endl;
        routePrice = 99;
    }
    void route_Dh_to_Shrpr()
    {
        cout << "Your selected route: Dhaka - Sherpur, Route Length: 143 km" << endl;
        routePrice = 142;
    }
    void route_Dh_to_Srjgnj()
    {
        cout << "Your selected route: Dhaka - Sirajgonj, Route Length: 127 km" << endl;
        routePrice = 127;
    }
    void route_Dh_to_Snmgnj()
    {
        cout << "Your selected route: Dhaka - Sunamganj, Route Length: 159 km" << endl;
        routePrice = 159;
    }
    void route_Dh_to_Sylht()
    {
        cout << "Your selected route: Dhaka - Sylhet, Route Length: 238 km" << endl;
        routePrice = 238;
    }
    void route_Dh_to_Tngl()
    {
        cout << "Your selected route: Dhaka - Tangail, Route Length: 84 km" << endl;
        routePrice = 84;
    }
    void route_Dh_to_Thkrgn()
    {
        cout << "Your selected route: Dhaka - Thakurgaon, Route Length: 389 km" << endl;
        routePrice = 389;
    }
    void showWrongInput()  // Showning Wrong Input for Wrong Pressing
    {
        cout << "You have pressed wrong input... Please Choose Right Option" << endl;
    }
    void setRoutePrice(float routeprice)
    {
        routePrice = routeprice;
    }
    float getRoutePrice()
    {
        return routePrice;
    }
};
class Driver
{
protected:
    float driverServiceCharge;
public:
    void show_Drivers_Full_Profile()  // Showing All Drivers Information In One Function
    {
        driver_Firoz_Shah();
        driver_Farhad_Khan();
        driver_Akthar_Uz_Zaman();
        driver_Abdul_Hamid();
        driver_Afsar_Hasan();
        driver_Belal_Khan();
        driver_Liton_De_Costa();
        driver_Jamiul_Alam();
        driver_Md_Mamum_Khan();
        driver_Arnoy_Shen();
        driver_Anamul_Haque();
        driver_Toffazzal_Mia();
        driver_Anayet_Hasan();
        driver_Afsar_Ali();
        driver_Kabul_Sheik();
        driver_Hamset_Borua();
        driver_Mithun_Pathan();
        driver_Somsher_Hasan();
        driver_Juel_Khan();
        driver_Rakib_Hossain();
        driver_Parimal_Barman();
        driver_Hashem_Khan();
        driver_Akash_Rai();
        driver_Azgor_Mia();
    }
    void driver_Firoz_Shah()
    {
        cout << "Driver Name:- Firoz Shah" << endl;
        cout << "Age:- 52" << endl;
        cout << "Home-District:- Khulna" << endl;
        cout << "Ranking:- Elite" << endl;
        cout << "Experience Rating (Out of 10):- 9.5" << endl;
        cout << "Driving Distance:-  1850000+ km" << endl;
        cout << "Driving Charge:- 7.0 tk/km" << endl;
        cout << "Special Experience:- International License from Australia" << endl;
        cout << "Driving Expert On:- All type of heavy-weight cargo on any route(include foggy).\n\n" << endl;
    }
    void driver_Farhad_Khan()
    {
        cout << "Driver Name:- Forhad Khan " << endl;
        cout << "Age:- 50" << endl;
        cout << "Home-District:- Rajshahi" << endl;
        cout << "Ranking:- Elite" << endl;
        cout << "Experience Rating (Out of 10):- 9.3" << endl;
        cout << "Driving Distance:-  1800000+ km" << endl;
        cout << "Driving Charge:- 6.7 tk/km" << endl;
        cout << "Special Experience:- International License from Canada" << endl;
        cout << "Driving Expert On:- All type of heavy-weight cargo on any route(master of mountain).\n\n" << endl;
    }
    void driver_Akthar_Uz_Zaman()
    {
        cout << "Driver Name:- Akthar_Uz_Zaman " << endl;
        cout << "Age:- 48" << endl;
        cout << "Home-District:- Dhaka" << endl;
        cout << "Ranking:- Elite" << endl;
        cout << "Experience Rating (Out of 10):- 9.1" << endl;
        cout << "Driving Distance:-  1750000+ km" << endl;
        cout << "Driving Charge:- 6.5 tk/km" << endl;
        cout << "Special Experience:- International License from Russia" << endl;
        cout << "Driving Expert On:- All type of heavy-weight cargo on any route(master of rainy way.\n\n" << endl;
    }
    void driver_Abdul_Hamid()
    {
        cout << "Driver Name:- Abdul Hamid" << endl;
        cout << "Age:- 47" << endl;
        cout << "Home-District:- Chittagong" << endl;
        cout << "Ranking:- Instructor" << endl;
        cout << "Experience Rating (Out of 10):- 8.8" << endl;
        cout << "Driving Distance:- 170000+ km" << endl;
        cout << "Driving Charge:- 6.4 tk/km" << endl;
        cout << "Special Experience:- International License from UK" << endl;
        cout << "Driving Expert On:- All type of mid-weight cargo on any route(include foggy).\n\n" << endl;
    }
    void driver_Afsar_Hasan()
    {
        cout << "Driver Name:- Afsar Hasan" << endl;
        cout << "Age:- 46" << endl;
        cout << "Home-District:- Cox's Bazar" << endl;
        cout << "Ranking:- Instructor" << endl;
        cout << "Experience Rating (Out of 10):- 8.6" << endl;
        cout << "Driving Distance:- 165000+ km" << endl;
        cout << "Driving Charge:- 6.2 tk/km" << endl;
        cout << "Special Experience:- International License from UAE" << endl;
        cout << "Driving Expert On:- All type of mid-weight cargo on any route(mountain rainy way).\n\n" << endl;
    }
    void driver_Belal_Khan()
    {
        cout << "Driver Name:- Belal Khan " << endl;
        cout << "Age:- 45" << endl;
        cout << "Home-District:- Meherpur" << endl;
        cout << "Ranking:- Instructor" << endl;
        cout << "Experience Rating (Out of 10):- 8.5" << endl;
        cout << "Driving Distance:- 160000+ km" << endl;
        cout << "Driving Charge:- 6.1 tk/km" << endl;
        cout << "Special Experience:- International License from Spain" << endl;
        cout << "Driving Expert On:- All type of mid-weight cargo on any route(desert way).\n\n" << endl;
    }
    void driver_Liton_De_Costa()
    {
        cout << "Driver Name:- Liton De Costa " << endl;
        cout << "Age:- 44" << endl;
        cout << "Home-District:- Barnmanbaria" << endl;
        cout << "Ranking:- Instructor" << endl;
        cout << "Experience Rating (Out of 10):- 8.3" << endl;
        cout << "Driving Distance:- 155000+ km" << endl;
        cout << "Driving Charge:- 6.0 tk/km" << endl;
        cout << "Special Experience:- International License from Katar" << endl;
        cout << "Driving Expert On:- All type of mid-weight cargo on any route(rocky way).\n\n" << endl;
    }
    void driver_Jamiul_Alam()
    {
        cout << "Driver Name:- Jamiul Alam" << endl;
        cout << "Age:- 42" << endl;
        cout << "Home-District:- Khagrachari" << endl;
        cout << "Ranking:- Instructor" << endl;
        cout << "Experience Rating (Out of 10):- 8.1" << endl;
        cout << "Driving Distance:- 1500000+ km" << endl;
        cout << "Driving Charge:- 5.9 tk/km" << endl;
        cout << "Special Experience:- International License from Italy" << endl;
        cout << "Driving Expert On:- All type of mid-weight cargo on any route.\n\n" << endl;
    }
    void driver_Md_Mamum_Khan()
    {
        cout << "Driver Name:- Md. Mamum Khan" << endl;
        cout << "Age:- 41" << endl;
        cout << "Home-District:- Rajbari" << endl;
        cout << "Ranking:- Master" << endl;
        cout << "Experience Rating (Out of 10):- 7.9" << endl;
        cout << "Driving Distance:- 1450000+ km" << endl;
        cout << "Driving Charge:- 5.8 tk/km" << endl;
        cout << "Special Experience:- Troubling Whole Routes of Bangladesh" << endl;
        cout << "Driving Expert On:- All type of cargo on any route of Bangladesh.\n\n" << endl;
    }
    void driver_Arnoy_Shen()
    {
        cout << "Driver Name:- Arnoy Shen" << endl;
        cout << "Age:- 39" << endl;
        cout << "Home-District:- Panchagarh" << endl;
        cout << "Ranking:- Master" << endl;
        cout << "Experience Rating (Out of 10):- 7.7" << endl;
        cout << "Driving Distance:- 1400000+ km" << endl;
        cout << "Driving Charge: - 5.7 tk/km" << endl;
        cout << "Driving Expert On:- All type of heavy-weight cargo on any hilly road of Bangladesh.\n\n" << endl;
    }
    void driver_Anamul_Haque()
    {
        cout << "Driver Name:- Anamul Haque" << endl;
        cout << "Age:- 37" << endl;
        cout << "Home-District:- Norail" << endl;
        cout << "Ranking:- Professional" << endl;
        cout << "Experience Rating (Out of 10):- 7.6" << endl;
        cout << "Driving Distance:- 1350000+ km" << endl;
        cout << "Driving Charge:- 5.6 tk/km" << endl;
        cout << "Driving Expert On:- All type of mid-weight cargo on streat route.\n\n" << endl;
    }
    void driver_Toffazzal_Mia()
    {
        cout << "Driver Name:- Toffazzal Mia" << endl;
        cout << "Age:- 36" << endl;
        cout << "Home-District:- Natore" << endl;
        cout << "Ranking:- Professional" << endl;
        cout << "Experience Rating (Out of 10):- 7.4" << endl;
        cout << "Driving Distance:- 1250000+ km" << endl;
        cout << "Driving Charge:- 5.5 tk/km" << endl;
        cout << "Driving Expert On:- All type of low-weight cargo on streat route.\n\n" << endl;
    }
    void driver_Anayet_Hasan()
    {
        cout << "Driver Name:- Md.  Anayet Hasan" << endl;
        cout << "Age:- 34" << endl;
        cout << "Home-District:- Lakshmipur" << endl;
        cout << "Ranking:- Professional" << endl;
        cout << "Experience Rating (Out of 10):- 7.2" << endl;
        cout << "Driving Distance:- 1150000+ km" << endl;
        cout << "Driving Charge:- 5.3 tk/km\n\n" << endl;
    }
    void driver_Afsar_Ali()
    {
        cout << "Driver Name:- Afsar Ali" << endl;
        cout << "Age:- 33" << endl;
        cout << "Home-District:- Jessore" << endl;
        cout << "Ranking:- Professional" << endl;
        cout << "Experience Rating (Out of 10):- 7.1" << endl;
        cout << "Driving Distance:- 1050000+ km" << endl;
        cout << "Driving Charge:- 5.2 tk/km\n\n" << endl;
    }
    void driver_Kabul_Sheik()
    {
        cout << "Driver Name:- Kabul Sheik" << endl;
        cout << "Age:- 32" << endl;
        cout << "Home-District:- Gazipur" << endl;
        cout << "Ranking:- Professional" << endl;
        cout << "Experience Rating (Out of 10):- 7.0" << endl;
        cout << "Driving Distance:- 1000000+ km" << endl;
        cout << "Driving Charge:- 5.0 tk/km\n\n" << endl;
    }
    void driver_Hamset_Borua()
    {
        cout << "Driver Name:- Hamset Borua" << endl;
        cout << "Age:- 31" << endl;
        cout << "Home-District:- Bogra" << endl;
        cout << "Ranking:- Worker" << endl;
        cout << "Experience Rating (Out of 10):- 6.8" << endl;
        cout << "Driving Distance:- 850000+ km" << endl;
        cout << "Driving Charge:- 4.8 tk/km\n\n" << endl;
    }
    void driver_Mithun_Pathan()
    {
        cout << "Driver Name:- Mithun Pathan" << endl;
        cout << "Age:- 30" << endl;
        cout << "Home-District:- Sherpur" << endl;
        cout << "Ranking:- Worker" << endl;
        cout << "Experience Rating (Out of 10):- 6.7" << endl;
        cout << "Driving Distance:- 700000+ km" << endl;
        cout << "Driving Charge:- 4.7 tk/km\n\n" << endl;
    }
    void driver_Somsher_Hasan()
    {
        cout << "Driver Name:- Somsher Hasan" << endl;
        cout << "Age:- 29" << endl;
        cout << "Home-District:- Moulavibazar" << endl;
        cout << "Ranking:- Worker" << endl;
        cout << "Experience Rating (Out of 10):- 6.6" << endl;
        cout << "Driving Distance:- 650000+ km" << endl;
        cout << "Driving Charge:- 4.5 tk/km\n\n" << endl;
    }
    void driver_Juel_Khan()
    {
        cout << "Driver Name:- Juel Khan" << endl;
        cout << "Age:- 28" << endl;
        cout << "Home-District:- Manikganj" << endl;
        cout << "Ranking:- Worker" << endl;
        cout << "Experience Rating (Out of 10):- 6.5" << endl;
        cout << "Driving Distance:- 550000+ km" << endl;
        cout << "Driving Charge:- 4.4 tk/km\n\n" << endl;
    }
    void driver_Rakib_Hossain()
    {
        cout << "Driver Name:- Rakib Hossain" << endl;
        cout << "Age:- 27" << endl;
        cout << "Home-District:- Kushtia" << endl;
        cout << "Ranking:- Worker" << endl;
        cout << "Experience Rating (Out of 10):- 6.3" << endl;
        cout << "Driving Distance:- 500000+ km" << endl;
        cout << "Driving Charge:- 4.2 tk/km\n\n" << endl;
    }
    void driver_Parimal_Barman()
    {
        cout << "Driver Name:- Parimal Barman" << endl;
        cout << "Age:- 26" << endl;
        cout << "Home-District:- Noakhali" << endl;
        cout << "Ranking:- Worker" << endl;
        cout << "Experience Rating (Out of 10):- 6.1" << endl;
        cout << "Driving Distance:- 450000+ km" << endl;
        cout << "Driving Charge:- 4.1 tk/km\n\n" << endl;
    }
    void driver_Hashem_Khan()
    {
        cout << "Driver Name:- Hashem Khan" << endl;
        cout << "Age:- 25" << endl;
        cout << "Home-District:- Nawabgonj" << endl;
        cout << "Ranking:- Worker" << endl;
        cout << "Experience Rating (Out of 10):- 6.0" << endl;
        cout << "Driving Distance:- 350000+ km" << endl;
        cout << "Driving Charge:- 4.0 tk/km\n\n" << endl;
    }
    void driver_Akash_Rai()
    {
        cout << "Driver Name:- Akash Rai" << endl;
        cout << "Age:- 24" << endl;
        cout << "Home-District:- Sylhet" << endl;
        cout << "Ranking:- Worker" << endl;
        cout << "Experience Rating (Out of 10):- 5.8" << endl;
        cout << "Driving Distance:- 250000+ km" << endl;
        cout << "Driving Charge:- 3.9 tk/km\n\n" << endl;
    }
    void driver_Azgor_Mia()
    {
        cout << "Driver Name:- Azgor Mia" << endl;
        cout << "Age:- 23" << endl;
        cout << "Home-District:- Patuakhali" << endl;
        cout << "Ranking:- Worker" << endl;
        cout << "Experience Rating (Out of 10):- 5.5" << endl;
        cout << "Driving Distance:- 150000+ km" << endl;
        cout << "Driving Charge:- 3.8 tk/km\n\n" << endl;
    }
    void driver_Firoz_Shah_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Firoz Shah" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 9.5" << endl;
        cout << "\t\t\tDriving Charge:- 7.0 tk/km\n\n" << endl;
        driverServiceCharge = 7.0;
    }
    void driver_Farhad_Khan_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Forhad Khan " << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 9.3" << endl;
        cout << "\t\t\tDriving Charge:- 6.7 tk/km\n\n" << endl;
        driverServiceCharge = 6.7;
    }
    void driver_Akthar_Uz_Zaman_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Akthar_Uz_Zaman " << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 9.1" << endl;
        cout << "\t\t\tDriving Charge:- 6.5 tk/km\n\n" << endl;
        driverServiceCharge = 6.5;
    }
    void driver_Abdul_Hamid_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Abdul Hamid" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 8.8" << endl;
        cout << "\t\t\tDriving Charge:- 6.4 tk/km\n\n" << endl;
        driverServiceCharge = 6.4;
    }
    void driver_Afsar_Hasan_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Afsar Hasan" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 8.6" << endl;
        cout << "\t\t\tDriving Charge:- 6.2 tk/km\n\n" << endl;
        driverServiceCharge = 6.2;
    }
    void driver_Belal_Khan_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Belal Khan " << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 8.5" << endl;
        cout << "\t\t\tDriving Charge:- 6.1 tk/km\n\n" << endl;
        driverServiceCharge = 6.1;
    }
    void driver_Liton_De_Costa_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Liton De Costa " << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 8.3" << endl;
        cout << "\t\t\tDriving Charge:- 6.0 tk/km\n\n" << endl;
        driverServiceCharge = 6.0;
    }
    void driver_Jamiul_Alam_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Jamiul Alam" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 8.1" << endl;
        cout << "\t\t\tDriving Charge:- 5.9 tk/km\n\n" << endl;
        driverServiceCharge = 5.9;
    }
    void driver_Md_Mamum_Khan_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Md. Mamum Khan" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 7.9" << endl;
        cout << "\t\t\tDriving Charge:- 5.8 tk/km\n\n" << endl;
        driverServiceCharge = 5.8;
    }
    void driver_Arnoy_Shen_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Arnoy Shen" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 7.7" << endl;
        cout << "\t\t\tDriving Charge: - 5.7 tk/km\n\n" << endl;
        driverServiceCharge = 5.7;
    }
    void driver_Anamul_Haque_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Anamul Haque" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 7.6" << endl;
        cout << "\t\t\tDriving Charge:- 5.6 tk/km\n\n" << endl;
        driverServiceCharge = 5.6;
    }
    void driver_Toffazzal_Mia_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Toffazzal Mia" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 7.4" << endl;
        cout << "\t\t\tDriving Charge:- 5.5 tk/km\n\n" << endl;
        driverServiceCharge = 5.5;
    }
    void driver_Anayet_Hasan_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Md.  Anayet Hasan" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 7.2" << endl;
        cout << "\t\t\tDriving Charge:- 5.3 tk/km\n\n" << endl;
        driverServiceCharge = 5.3;
    }
    void driver_Afsar_Ali_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Afsar Ali" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 7.1" << endl;
        cout << "\t\t\tDriving Charge:- 5.2 tk/km\n\n" << endl;
        driverServiceCharge = 5.2;
    }
    void driver_Kabul_Sheik_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Kabul Sheik" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 7.0" << endl;
        cout << "\t\t\tDriving Charge:- 5.0 tk/km\n\n" << endl;
        driverServiceCharge = 5.0;
    }
    void driver_Hamset_Borua_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Hamset Borua" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 6.8" << endl;
        cout << "\t\t\tDriving Charge:- 4.8 tk/km\n\n" << endl;
        driverServiceCharge = 4.8;
    }
    void driver_Mithun_Pathan_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Mithun Pathan" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 6.7" << endl;
        cout << "\t\t\tDriving Charge:- 4.7 tk/km\n\n" << endl;
        driverServiceCharge = 4.7;
    }
    void driver_Somsher_Hasan_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Somsher Hasan" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 6.6" << endl;
        cout << "\t\t\tDriving Charge:- 4.5 tk/km\n\n" << endl;
        driverServiceCharge = 4.5;
    }
    void driver_Juel_Khan_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Juel Khan" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 6.5" << endl;
        cout << "\t\t\tDriving Charge:- 4.4 tk/km\n\n" << endl;
        driverServiceCharge = 4.4;
    }
    void driver_Rakib_Hossain_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Rakib Hossain" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 6.3" << endl;
        cout << "\t\t\tDriving Charge:- 4.2 tk/km\n\n" << endl;
        driverServiceCharge = 4.2;
    }
    void driver_Parimal_Barman_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Parimal Barman" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 6.1" << endl;
        cout << "\t\t\tDriving Charge:- 4.1 tk/km\n\n" << endl;
        driverServiceCharge = 4.1;
    }
    void driver_Hashem_Khan_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Hashem Khan" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 6.0" << endl;
        cout << "\t\t\tDriving Charge:- 4.0 tk/km\n\n" << endl;
        driverServiceCharge = 4.0;
    }
    void driver_Akash_Rai_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Akash Rai" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 5.8" << endl;
        cout << "\t\t\tDriving Charge:- 3.9 tk/km\n\n" << endl;
        driverServiceCharge = 3.9;
    }
    void driver_Azgor_Mia_srt_prf()
    {
        cout << "\t\t\tDriver Name:- Azgor Mia" << endl;
        cout << "\t\t\tExperience Rating (Out of 10):- 5.5" << endl;
        cout << "\t\t\tDriving Charge:- 3.8 tk/km\n\n" << endl;
        driverServiceCharge = 3.8;
    }
    void showWrongInput()  // Showning Wrong Input for Wrong Pressing
    {
        cout << "You have pressed wrong input... Please Choose Right Option" << endl;
    }
    void setDriverServiceCharge(float driverservicecharge)
    {
        driverServiceCharge = driverservicecharge;
    }
    float getDriverServiceCharge()
    {
        return driverServiceCharge;
    }
};

class Truck
{
protected:
    float truckServiceCharge;
public:
    void showTruckList()  // Showing Truck List
    {
        static int i = 0;
        cout << "\n    **********************************************************************     \n" << endl;
        cout <<" "<< ++i <<". Mercedes-Benz _ Service Charge - 3.00 tk/km" << endl;
        cout <<" "<< ++i <<". Scania        _ Service Charge - 2.75 tk/km" << endl;
        cout <<" "<< ++i <<". Vovlo         _ Service Charge - 2.75 tk/km" << endl;
        cout <<" "<< ++i <<". Daf           _ Service Charge - 2.50 tk/km" << endl;
        cout <<" "<< ++i <<". Iveco         _ Service Charge - 2.50 tk/km" << endl;
        cout <<" "<< ++i <<". Man           _ Service Charge - 2.25 tk/km" << endl;
        cout <<" "<< ++i <<". Reliant-Truck _ Service Charge - 2.25 tk/km" << endl;
        cout <<" "<< ++i <<". Majestic      _ Service Charge - 2.00 tk/km" << endl;
        cout <<" "<< ++i <<". Hino          _ Service Charge - 2.00 tk/km" << endl;
        cout << ++i <<". Toyota        _ Service Charge - 1.75 tk/km"      << endl;
        cout << ++i <<". Tata          _ Service Charge - 1.75 tk/km"      << endl;
        cout << ++i <<". Ashok-Leyland _ Service Charge - 1.50 tk/km"      << endl;
        cout << "\n    **********************************************************************     \n" << endl;
    }
    void showMercedes_benz()
    {
        cout << "\t\tMercedes-benz" << endl;
        cout << "\t\tIt's service charge- 3.00 tk/km\n\n" << endl;
        truckServiceCharge = 3.00;
    }
    void showScania()
    {
        cout << "\t\tScania" << endl;
        cout << "\t\tIt's service charge- 2.75 tk/km\n\n" << endl;
        truckServiceCharge = 2.75;
    }
    void showVolvo()
    {
        cout << "\t\tVolvo" << endl;
        cout << "\t\tIt's service charge- 2.75 tk/km\n\n" << endl;
        truckServiceCharge = 2.75;
    }
    void showDaf()
    {
        cout << "\t\tDaf" << endl;
        cout << "\t\tIt's service charge- 2.50 tk/km\n\n" << endl;
        truckServiceCharge = 2.50;
    }
    void showIveco()
    {
        cout << "\t\tIveco" << endl;
        cout << "\t\tIt's service charge- 2.50 tk/km\n\n" << endl;
        truckServiceCharge = 2.50;
    }
    void showMan()
    {
        cout << "\t\tMan" << endl;
        cout << "\t\tIt's service charge- 2.25 tk/km\n\n" << endl;
        truckServiceCharge = 2.25;
    }
    void showReliant_Truck()
    {
        cout << "\t\tReliant-Truck" << endl;
        cout << "\t\tIt's service charge- 2.25 tk/km\n\n" << endl;
        truckServiceCharge = 2.25;
    }
    void showMajestic()
    {
        cout << "\t\tMajestic" << endl;
        cout << "\t\tIt's service charge- 2.00 tk/km\n\n" << endl;
        truckServiceCharge = 2.00;
    }
    void showHino()
    {
        cout << "\t\tHino" << endl;
        cout << "\t\tIt's service charge- 2.00 tk/km\n\n" << endl;
        truckServiceCharge = 2.00;
    }
    void showToyota()
    {
        cout << "\t\tToyota" << endl;
        cout << "\t\tIt's service charge- 1.75 tk/km\n\n" << endl;
        truckServiceCharge = 1.75;
    }
    void showTata()
    {
        cout << "\t\tTata" << endl;
        cout << "\t\tIt's service charge- 1.75 tk/km\n\n" << endl;
        truckServiceCharge = 1.75;
    }
    void showAshok_Leyland()
    {
        cout << "\t\tAshok-Leyland" << endl;
        cout << "\t\tIt's service charge- 1.50 tk/km\n\n" << endl;
        truckServiceCharge = 1.50;
    }
    void setTruckServiceCharge(float truckservicecharge)
    {
        truckServiceCharge = truckservicecharge;
    }
    float getTruckServiceCharge()
    {
        return truckServiceCharge;
    }
};

class Time
{
public:
    void showTimeList()  // Showing Time List
    {
        cout << "\n    **********************************************************************     \n" << endl;
        cout << "Saturday-  ";
        cout << "7am\n          11am\n           3pm\n           8pm\n" << endl;
        cout << "Sunday-    ";
        cout << "8am\n           1pm\n           5pm\n           9pm\n" << endl;
        cout << "Monday-    ";
        cout << "9am\n           2am\n           6pm\n          11pm\n" << endl;
        cout << "Tuesday-   ";
        cout << "6am\n          11am\n           5pm\n          12am\n" << endl;
        cout << "Wednesday- ";
        cout << "9am\n           1pm\n           4pm\n          10pm\n" << endl;
        cout << "Thursday-  ";
        cout << "8am\n          12pm\n           7pm\n          12am\n" << endl;
        cout << "Friday-    ";
        cout << "7am\n          11am\n           2pm\n           9pm\n" << endl;
        cout << "\n    **********************************************************************     \n" << endl;
    }
    void time_6_am()
    {
        cout << "\tTime- 6 am\n" << endl;
    }
    void time_7_am()
    {
        cout << "\tTime- 7 am\n" << endl;
    }
    void time_8_am()
    {
        cout << "\tTime- 8 am\n" << endl;
    }
    void time_9_am()
    {
        cout << "\tTime- 9 am\n" << endl;
    }
    void time_11_am()
    {
        cout << "\tTime- 11 am\n" << endl;
    }
    void time_12_am()
    {
        cout << "\tTime- 12 am\n" << endl;
    }
    void time_1_pm()
    {
        cout << "\tTime- 1 pm\n" << endl;
    }
    void time_2_pm()
    {
        cout << "\tTime- 2 pm\n" << endl;
    }
    void time_3_pm()
    {
        cout << "\tTime- 3 pm\n" << endl;
    }
    void time_4_pm()
    {
        cout << "\tTime- 4 pm\n" << endl;
    }
    void time_5_pm()
    {
        cout << "\tTime- 2 pm\n" << endl;
    }
    void time_6_pm()
    {
        cout << "\tTime- 6 pm\n" << endl;
    }
    void time_7_pm()
    {
        cout << "\tTime- 7 pm\n" << endl;
    }
    void time_8_pm()
    {
        cout << "\tTime- 8 pm\n" << endl;
    }
    void time_9_pm()
    {
        cout << "\tTime- 9 pm\n" << endl;
    }
    void time_10_pm()
    {
        cout << "\tTime- 10 pm\n" << endl;
    }
    void time_11_pm()
    {
        cout << "\tTime- 11 pm\n" << endl;
    }
    void time_12_pm()
    {
        cout << "\tTime- 12 pm\n" << endl;
    }
};

class Truck_Driver_Management : public Driver  // Multi-Level Inheritance
{
public:
    // Specifing Drivers on All Trucks
    void setMercedes_benz_Driver()
    {
        int enter = 0;
        while(enter==0)
        {
            int Driver_Choose;
            cout << "\n\n\t\tAvaible Drivers- \n\n" << endl;
            cout << "\t\t\t1.\n";driver_Firoz_Shah_srt_prf();
            cout << "\t\t\t2.\n";driver_Abdul_Hamid_srt_prf();
            cout <<"\n\t\t\tEnter- ";
            cin >> Driver_Choose;
            fflush(stdin);
            cout << "\n";

            if (Driver_Choose > 2)
            {showWrongInput();}
            else{enter=1;}

            switch (Driver_Choose)
            {
            case 1:
                driver_Firoz_Shah_srt_prf();break;
            case 2:
                driver_Abdul_Hamid_srt_prf();break;
            default:
                showWrongInput();
            }
        }
    }
    void setScania_Driver()
    {
        int enter = 0;
        while(enter==0)
        {
            int Driver_Choose;
            cout << "\n\n\t\tAvaible Drivers- \n\n" << endl;
            cout << "\t\t\t1.\n";driver_Farhad_Khan_srt_prf();
            cout << "\t\t\t2.\n";driver_Md_Mamum_Khan_srt_prf();
            cout <<"\n\t\t\tEnter- ";
            cin >> Driver_Choose;
            fflush(stdin);
            cout << "\n";

            if (Driver_Choose > 2)
            {showWrongInput();}
            else{enter=1;}

            switch (Driver_Choose)
            {
            case 1:
                driver_Farhad_Khan_srt_prf();break;
            case 2:
                driver_Md_Mamum_Khan_srt_prf();break;
            default:
                showWrongInput();
            }
        }
    }
    void setVolvo_Driver()
    {
        int enter = 0;
        while(enter==0)
        {
            int Driver_Choose;
            cout << "\n\n\t\tAvaible Drivers- \n\n" << endl;
            cout << "\t\t\t1.\n";driver_Akthar_Uz_Zaman_srt_prf();
            cout << "\t\t\t2.\n";driver_Anamul_Haque_srt_prf();
            cout <<"\n\t\t\tEnter- ";
            cin >> Driver_Choose;
            fflush(stdin);
            cout << "\n";

            if (Driver_Choose > 2)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Driver_Choose)
            {
            case 1:
                driver_Akthar_Uz_Zaman_srt_prf();break;
            case 2:
                driver_Anamul_Haque_srt_prf();break;
            default:
                showWrongInput();
            }
        }
    }
    void setDaf_Driver()
    {
        int enter = 0;
        while(enter==0)
        {
            int Driver_Choose;
            cout << "\n\n\t\tAvaible Drivers- \n\n" << endl;
            cout << "\t\t\t1.\n";driver_Afsar_Hasan_srt_prf();
            cout << "\t\t\t2.\n";driver_Mithun_Pathan_srt_prf();
            cout <<"\n\t\t\tEnter- ";
            cin >> Driver_Choose;
            fflush(stdin);
            cout << "\n";

            if (Driver_Choose > 2)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Driver_Choose)
            {
            case 1:
                driver_Afsar_Hasan_srt_prf();break;
            case 2:
                driver_Mithun_Pathan_srt_prf();break;
            default:
                showWrongInput();
            }
        }
    }
    void setIveco_Driver()
    {
        int enter = 0;
        while(enter==0)
        {
            int Driver_Choose;
            cout << "\n\n\t\tAvaible Drivers- \n\n" << endl;
            cout << "\t\t\t1.\n";driver_Belal_Khan_srt_prf();
            cout << "\t\t\t2.\n";driver_Parimal_Barman_srt_prf();
            cout <<"\n\t\t\tEnter- ";
            cin >> Driver_Choose;
            fflush(stdin);
            cout << "\n";

            if (Driver_Choose > 2)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Driver_Choose)
            {
            case 1:
                driver_Belal_Khan_srt_prf();break;
            case 2:
                driver_Parimal_Barman_srt_prf();break;
            default:
                showWrongInput();
            }
        }
    }
    void setMan_Driver()
    {
        int enter = 0;
        while(enter==0)
        {
            int Driver_Choose;
            cout << "\n\n\t\tAvaible Drivers- \n\n" << endl;
            cout << "\t\t\t1.\n";driver_Liton_De_Costa_srt_prf();
            cout << "\t\t\t2.\n";driver_Hashem_Khan_srt_prf();
            cout <<"\n\t\t\tEnter- ";
            cin >> Driver_Choose;
            fflush(stdin);
            cout << "\n";

            if (Driver_Choose > 2)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Driver_Choose)
            {
            case 1:
                driver_Liton_De_Costa_srt_prf();break;
            case 2:
                driver_Hashem_Khan_srt_prf();break;
            default:
                showWrongInput();
            }
        }
    }
    void setReliant_Truck_Driver()
    {
        int enter = 0;
        while(enter==0)
        {
            int Driver_Choose;
            cout << "\n\n\t\tAvaible Drivers- \n\n" << endl;
            cout << "\t\t\t1.\n";driver_Jamiul_Alam_srt_prf();
            cout << "\t\t\t2.\n";driver_Akash_Rai_srt_prf();
            cout <<"\n\t\t\tEnter- ";
            cin >> Driver_Choose;
            fflush(stdin);
            cout << "\n";

            if (Driver_Choose > 2)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Driver_Choose)
            {
            case 1:
                driver_Jamiul_Alam_srt_prf();break;
            case 2:
                driver_Akash_Rai_srt_prf();break;
            default:
                showWrongInput();
            }
        }
    }
    void setMajestic_Driver()
    {
        int enter = 0;
        while(enter==0)
        {
            int Driver_Choose;
            cout << "\n\n\t\tAvaible Drivers- \n\n" << endl;
            cout << "\t\t\t1.\n";driver_Arnoy_Shen_srt_prf();
            cout << "\t\t\t2.\n";driver_Rakib_Hossain_srt_prf();
            cout <<"\n\t\t\tEnter- ";
            cin >> Driver_Choose;
            fflush(stdin);
            cout << "\n";

            if (Driver_Choose > 2)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Driver_Choose)
            {
            case 1:
                driver_Arnoy_Shen_srt_prf();break;
            case 2:
                driver_Rakib_Hossain_srt_prf();break;
            default:
                showWrongInput();
            }
        }
    }
    void setHino_Driver()
    {
        int enter = 0;
        while(enter==0)
        {
            int Driver_Choose;
            cout << "\n\n\t\tAvaible Drivers- \n\n" << endl;
            cout << "\t\t\t1.\n";driver_Toffazzal_Mia_srt_prf();
            cout << "\t\t\t2.\n";driver_Juel_Khan_srt_prf();
            cout <<"\n\t\t\tEnter- ";
            cin >> Driver_Choose;
            fflush(stdin);
            cout << "\n";

            if (Driver_Choose > 2)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Driver_Choose)
            {
            case 1:
                driver_Toffazzal_Mia_srt_prf();break;
            case 2:
                driver_Juel_Khan_srt_prf();break;
            default:
                showWrongInput();
            }
        }
    }
    void setToyota_Driver()
    {
        int enter = 0;
        while(enter==0)
        {
            int Driver_Choose;
            cout << "\n\n\t\tAvaible Drivers- \n\n" << endl;
            cout << "\t\t\t1.\n";driver_Anayet_Hasan_srt_prf();
            cout << "\t\t\t2.\n";driver_Azgor_Mia_srt_prf();
            cout <<"\t\t\t\nEnter- ";
            cin >> Driver_Choose;
            fflush(stdin);
            cout << "\n";

            if (Driver_Choose > 2)
            {showWrongInput();}
            else
            {
                enter=1;
            }

            switch (Driver_Choose)
            {
            case 1:
                driver_Anayet_Hasan_srt_prf();break;
            case 2:
                driver_Azgor_Mia_srt_prf();break;
            default:
                showWrongInput();
            }
        }
    }
    void setTata_Driver()
    {
        int enter = 0;
        while(enter==0)
        {
            int Driver_Choose;
            cout << "\n\n\t\tAvaible Drivers- \n\n" << endl;
            cout << "\t\t\t1.\n";driver_Afsar_Ali_srt_prf();
            cout << "\t\t\t2.\n";driver_Somsher_Hasan_srt_prf();
            cout <<"\n\t\t\tEnter- ";
            cin >> Driver_Choose;
            fflush(stdin);
            cout << "\n";

            if (Driver_Choose > 2)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Driver_Choose)
            {
            case 1:
                driver_Afsar_Ali_srt_prf();break;
            case 2:
                driver_Somsher_Hasan_srt_prf();break;
            default:
                showWrongInput();
            }
        }
    }
    void setAshok_Layland_Driver()
    {
        int enter = 0;
        while(enter==0)
        {
            int Driver_Choose;
            cout << "\n\n\t\tAvaible Drivers- \n\n" << endl;
            cout << "\t\t\t1.\n";driver_Kabul_Sheik_srt_prf();
            cout << "\t\t\t2.\n";driver_Hamset_Borua_srt_prf();
            cout <<"\n\t\t\tEnter- ";
            cin >> Driver_Choose;
            fflush(stdin);
            cout << "\n";

            if (Driver_Choose > 2)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Driver_Choose)
            {
            case 1:
                driver_Kabul_Sheik_srt_prf();break;
            case 2:
                driver_Hamset_Borua_srt_prf();break;
            default:
                showWrongInput();
            }
        }
    }
};

class Day : public Truck, public Time, public Truck_Driver_Management   // Multiple Inheritance
{
public:
    void showDayList()
    {
        cout << "1.Saturday" << endl;
        cout << "2.Sunday"   << endl;
        cout << "3.Monday"   << endl;
        cout << "4.Tuesday"  << endl;
        cout << "5.Wednesday"<< endl;
        cout << "6.Thursday"  << endl;
        cout << "7.Friday"   << endl;
    }
    void Saturday()   // Specifing Trucks On Saturday
    {
        cout << "\tYour selected day:- Saturday" << endl;
        cout << "\tIn Saturday our departure time...\n" << endl;
        int enter = 0;
        while(enter==0)
        {
            int Time_Choose;
            cout << "\tAvailable Truck's Time- \n\n" << endl;
            cout << "\t1.";time_7_am();
            cout << "\t2.";time_11_am();
            cout << "\t3.";time_3_pm();
            cout << "\t4.";time_8_pm();
            cout <<"\n\tEnter- ";
            cin >> Time_Choose;
            fflush(stdin);
            cout << "\n";

            if (Time_Choose > 4)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Time_Choose)
            {
            case 1:
                time_7_am();  // Trucks & Drivers of Saturday- 7 am
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showMercedes_benz();
                        cout << "\t\t2.\n";showMan();
                        cout << "\t\t3.\n";showToyota();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showMercedes_benz();
                            setMercedes_benz_Driver();break;
                        case 2:
                            showMan();
                            setMan_Driver();break;
                        case 3:
                            showToyota();
                            setToyota_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 2:
                time_11_am();  // Trucks & Drivers of Saturday- 11 am
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";;showScania();
                        cout << "\t\t2.\n";;showHino();
                        cout << "\t\t3.\n";;showAshok_Leyland();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showScania();
                            setScania_Driver();break;
                        case 2:
                            showHino();
                            setHino_Driver();break;
                        case 3:
                            showAshok_Leyland();
                            setAshok_Layland_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 3:
                time_3_pm();  // Trucks & Drivers of Saturday- 3 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";;showVolvo();
                        cout << "\t\t2.\n";;showMajestic();
                        cout << "\t\t3.\n";;showTata();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showVolvo();
                            setVolvo_Driver();break;
                        case 2:
                            showMajestic();
                            setMajestic_Driver();break;
                        case 3:
                            showTata();
                            setTata_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 4:
                time_8_pm();  // Trucks & Drivers of Saturday- 8 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showDaf();
                        cout << "\t\t2.\n";showIveco();
                        cout << "\t\t3.\n";showReliant_Truck();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showDaf();
                            setDaf_Driver();break;
                        case 2:
                            showIveco();
                            setIveco_Driver();break;
                        case 3:
                            showReliant_Truck();
                            setReliant_Truck_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;
            default:
                showWrongInput();
            }
        }
    }
    void Sunday()   // Specifing Trucks On Sunday
    {
        cout << "\tYour selected day:- Sunday" << endl;
        cout << "\tIn Sunday our departure time...\n" << endl;
        int enter = 0;
        while(enter==0)
        {
            int Time_Choose;
            cout << "\tAvailable Truck's Time- \n\n" << endl;
            cout << "\t1.";time_8_am();
            cout << "\t2.";time_1_pm();
            cout << "\t3.";time_5_pm();
            cout << "\t4.";time_9_pm();
            cout <<"\n\tEnter- ";
            cin >> Time_Choose;
            fflush(stdin);
            cout << "\n";

            if (Time_Choose > 4)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Time_Choose)
            {
            case 1:
                time_8_am();  // Trucks & Drivers of Sunday- 8 am
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showScania();
                        cout << "\t\t2.\n";showVolvo();
                        cout << "\t\t3.\n";showTata();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showScania();
                            setScania_Driver();break;
                        case 2:
                            showVolvo();
                            setVolvo_Driver();break;
                        case 3:
                            showTata();
                            setTata_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 2:
                time_1_pm();  // Trucks & Drivers of Sunday- 1 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showMercedes_benz();
                        cout << "\t\t2.\n";showMan();
                        cout << "\t\t3.\n";showToyota();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showMercedes_benz();
                            setMercedes_benz_Driver();break;
                        case 2:
                            showMan();
                            setMan_Driver();break;
                        case 3:
                            showToyota();
                            setToyota_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 3:
                time_5_pm();  // Trucks & Drivers of Sunday- 5 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showDaf();
                        cout << "\t\t2.\n";showReliant_Truck();
                        cout << "\t\t3.\n";showAshok_Leyland();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showDaf();
                            setDaf_Driver();break;
                        case 2:
                            showReliant_Truck();
                            setReliant_Truck_Driver();break;
                        case 3:
                            showAshok_Leyland();
                            setAshok_Layland_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 4:
                time_9_pm();  // Trucks & Drivers of Sunday- 9 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showIveco();
                        cout << "\t\t2.\n";showMajestic();
                        cout << "\t\t3.\n";showHino();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showIveco();
                            setIveco_Driver();break;
                        case 2:
                            showMajestic();
                            setMajestic_Driver();break;
                        case 3:
                            showHino();
                            setHino_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;
            default:
                showWrongInput();
            }
        }
    }
    void Monday()   // Specifing Trucks On Monday
    {
        cout << "\tYour selected day:- Monday" << endl;
        cout << "\tIn Monday our departure time...\n" << endl;
        int enter = 0;
        while(enter==0)
        {
            int Time_Choose;
            cout << "\tAvailable Truck's Time- \n\n" << endl;
            cout << "\t1.";time_9_am();
            cout << "\t2.";time_2_pm();
            cout << "\t3.";time_6_pm();
            cout << "\t4.";time_11_pm();
            cout <<"\n\tEnter- ";
            cin >> Time_Choose;
            fflush(stdin);
            cout << "\n";

            if (Time_Choose > 4)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Time_Choose)
            {
            case 1:
                time_9_am();  // Trucks & Drivers of Monday- 9 am
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showVolvo();
                        cout << "\t\t2.\n";showMajestic();
                        cout << "\t\t3.\n";showHino();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showVolvo();
                            setVolvo_Driver();break;
                        case 2:
                            showMajestic();
                            setMajestic_Driver();break;
                        case 3:
                            showHino();
                            setHino_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 2:
                time_2_pm();  // Trucks & Drivers of Monday- 2 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showDaf();
                        cout << "\t\t2.\n";showMan();
                        cout << "\t\t3.\n";showTata();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showDaf();
                            setDaf_Driver();break;
                        case 2:
                            showMan();
                            setMan_Driver();break;
                        case 3:
                            showTata();
                            setTata_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 3:
                time_6_pm();  // Trucks & Drivers of Monday- 6 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showIveco();
                        cout << "\t\t2.\n";showReliant_Truck();
                        cout << "\t\t3.\n";showMajestic();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showIveco();
                            setIveco_Driver();break;
                        case 2:
                            showReliant_Truck();
                            setReliant_Truck_Driver();break;
                        case 3:
                            showMajestic();
                            setMajestic_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 4:
                time_11_pm();  // Trucks & Drivers of Monday- 11 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showMercedes_benz();
                        cout << "\t\t2.\n";showToyota();
                        cout << "\t\t3.\n";showAshok_Leyland();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showMercedes_benz();
                            setMercedes_benz_Driver();break;
                        case 2:
                            showToyota();
                            setToyota_Driver();break;
                        case 3:
                            showAshok_Leyland();
                            setAshok_Layland_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;
            default:
                showWrongInput();
            }
        }
    }
    void Tuesday()   // Specifing Trucks On Tuesday
    {
        cout << "\tYour selected day:- Tuesday" << endl;
        cout << "\tIn Tuesday our departure time...\n" << endl;
        int enter = 0;
        while(enter==0)
        {
            int Time_Choose;
            cout << "\tAvailable Truck's Time- \n\n" << endl;
            cout << "\t1.";time_6_am();
            cout << "\t2.";time_11_am();
            cout << "\t3.";time_5_pm();
            cout << "\t4.";time_12_am();
            cout <<"\n\tEnter- ";
            cin >> Time_Choose;
            fflush(stdin);
            cout << "\n";

            if (Time_Choose > 4)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Time_Choose)
            {
            case 1:
                time_6_am();  // Trucks & Drivers of Tuesday- 6 am
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showMercedes_benz();
                        cout << "\t\t2.\n";showMan();
                        cout << "\t\t3.\n";showToyota();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showMercedes_benz();
                            setMercedes_benz_Driver();break;
                        case 2:
                            showMan();
                            setMan_Driver();break;
                        case 3:
                            showToyota();
                            setToyota_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 2:
                time_11_am();  // Trucks & Drivers of Tuesday- 11 am
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showScania();
                        cout << "\t\t2.\n";showHino();
                        cout << "\t\t3.\n";showAshok_Leyland();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showScania();
                            setScania_Driver();break;
                        case 2:
                            showHino();
                            setHino_Driver();break;
                        case 3:
                            showAshok_Leyland();
                            setAshok_Layland_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 3:
                time_5_pm();  // Trucks & Drivers of Tuesday- 5 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showDaf();
                        cout << "\t\t2.\n";showReliant_Truck();
                        cout << "\t\t3.\n";showTata();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showDaf();
                            setDaf_Driver();break;
                        case 2:
                            showReliant_Truck();
                            setReliant_Truck_Driver();break;
                        case 3:
                            showTata();
                            setTata_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 4:
                time_12_am();  // Trucks & Drivers of Tuesday- 12 am
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showVolvo();
                        cout << "\t\t2.\n";showMajestic();
                        cout << "\t\t3.\n";showHino();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showVolvo();
                            setVolvo_Driver();break;
                        case 2:
                            showMajestic();
                            setMajestic_Driver();break;
                        case 3:
                            showHino();
                            setHino_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;
            default:
                showWrongInput();
            }
        }
    }
    void Wednesday()   // Specifing Trucks On Saturday
    {
        cout << "\tYour selected day:- Wednesday" << endl;
        cout << "\tIn Wednesday our departure time...\n" << endl;
        int enter = 0;
        while(enter==0)
        {
            int Time_Choose;
            cout << "\tAvailable Truck's Time- \n\n" << endl;
            cout << "\t1.";time_9_am();
            cout << "\t2.";time_1_pm();
            cout << "\t3.";time_4_pm();
            cout << "\t4.";time_10_pm();
            cout <<"\n\tEnter- ";
            cin >> Time_Choose;
            fflush(stdin);
            cout << "\n";

            if (Time_Choose > 4)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Time_Choose)
            {
            case 1:
                time_9_am();  // Trucks & Drivers of Wednesday- 9 am
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showVolvo();
                        cout << "\t\t2.\n";showMajestic();
                        cout << "\t\t3.\n";showHino();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showVolvo();
                            setVolvo_Driver();break;
                        case 2:
                            showMajestic();
                            setMajestic_Driver();break;
                        case 3:
                            showHino();
                            setHino_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 2:
                time_1_pm();  // Trucks & Drivers of Wednesday- 1 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showMercedes_benz();
                        cout << "\t\t2.\n";showMan();
                        cout << "\t\t3.\n";showToyota();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showMercedes_benz();
                            setMercedes_benz_Driver();break;
                        case 2:
                            showMan();
                            setMan_Driver();break;
                        case 3:
                            showToyota();
                            setToyota_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 3:
                time_4_pm();  // Trucks & Drivers of Wednesday- 4 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showScania();
                        cout << "\t\t2.\n";showDaf();
                        cout << "\t\t3.\n";showAshok_Leyland();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showScania();
                            setScania_Driver();break;
                        case 2:
                            showDaf();
                            setDaf_Driver();break;
                        case 3:
                            showAshok_Leyland();
                            setAshok_Layland_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 4:
                time_10_pm();  // Trucks & Drivers of Wednesday- 10 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showMercedes_benz();
                        cout << "\t\t2.\n";showIveco();
                        cout << "\t\t3.\n";showTata();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showMercedes_benz();
                            setMajestic_Driver();break;
                        case 2:
                            showIveco();
                            setIveco_Driver();break;
                        case 3:
                            showTata();
                            setTata_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;
            default:
                showWrongInput();
            }
        }
    }
    void Thursday()   // Specifing Trucks On Saturday
    {
        cout << "\tYour selected day:- Thursday" << endl;
        cout << "\tIn Thursday our departure time...\n" << endl;
        int enter = 0;
        while(enter==0)
        {
            int Time_Choose;
            cout << "\tAvailable Truck's Time- \n\n" << endl;
            cout << "\t1.";time_8_am();
            cout << "\t2.";time_12_pm();
            cout << "\t3.";time_7_pm();
            cout << "\t4.";time_12_am();
            cout <<"\n\tEnter- ";
            cin >> Time_Choose;
            fflush(stdin);
            cout << "\n";

            if (Time_Choose > 4)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Time_Choose)
            {
            case 1:
                time_8_am();  // Trucks & Drivers of Thursday- 8 am
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showScania();
                        cout << "\t\t2.\n";showVolvo();
                        cout << "\t\t3.\n";showTata();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showScania();
                            setScania_Driver();break;
                        case 2:
                            showVolvo();
                            setVolvo_Driver();break;
                        case 3:
                            showTata();
                            setTata_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 2:
                time_12_pm();  // Trucks & Drivers of Thursday- 12 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showMercedes_benz();
                        cout << "\t\t2.\n";showToyota();
                        cout << "\t\t3.\n";showAshok_Leyland();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showMercedes_benz();
                            setMajestic_Driver();break;
                        case 2:
                            showToyota();
                            setToyota_Driver();break;
                        case 3:
                            showAshok_Leyland();
                            setAshok_Layland_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 3:
                time_7_pm();  // Trucks & Drivers of Thursday- 7 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showIveco();
                        cout << "\t\t2.\n";showReliant_Truck();
                        cout << "\t\t3.\n";showMajestic();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showIveco();
                            setIveco_Driver();break;
                        case 2:
                            showReliant_Truck();
                            setReliant_Truck_Driver();break;
                        case 3:
                            showMajestic();
                            setMajestic_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 4:
                time_12_am();  // Trucks & Drivers of Thursday- 12 am
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showDaf();
                        cout << "\t\t2.\n";showMan();
                        cout << "\t\t3.\n";showHino();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showDaf();
                            setDaf_Driver();break;
                        case 2:
                            showMan();
                            setMan_Driver();break;
                        case 3:
                            showHino();
                            setHino_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;
            default:
                showWrongInput();
            }
        }
    }
    void Friday()   // Specifing Trucks On Saturday
    {
        cout << "\tYour selected day:- Friday" << endl;
        cout << "\tIn Friday our departure time...\n" << endl;
        int enter = 0;
        while(enter==0)
        {
            int Time_Choose;
            cout << "\tAvailable Truck's Time- \n\n" << endl;
            cout << "\t1.";time_7_am();
            cout << "\t2.";time_11_am();
            cout << "\t3.";time_2_pm();
            cout << "\t4.";time_9_pm();
            cout <<"\n\tEnter- ";
            cin >> Time_Choose;
            fflush(stdin);
            cout << "\n";

            if (Time_Choose > 4)
            {showWrongInput();}
            else
            {enter=1;}

            switch (Time_Choose)
            {
            case 1:
                time_7_am();  // Trucks & Drivers of Friday- 7 am
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showMercedes_benz();
                        cout << "\t\t2.\n";showMan();
                        cout << "\t\t3.\n";showToyota();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showMercedes_benz();
                            setMercedes_benz_Driver();break;
                        case 2:
                            showMan();
                            setMan_Driver();break;
                        case 3:
                            showToyota();
                            setToyota_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 2:
                time_11_am();  // Trucks & Drivers of Friday- 11 am
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showScania();
                        cout << "\t\t2.\n";showHino();
                        cout << "\t\t3.\n";showAshok_Leyland();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showScania();
                            setScania_Driver();break;
                        case 2:
                            showHino();
                            setHino_Driver();break;
                        case 3:
                            showAshok_Leyland();
                            setAshok_Layland_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 3:
                time_3_pm();  // Trucks & Drivers of Friday- 3 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showVolvo();
                        cout << "\t\t2.\n";showMajestic();
                        cout << "\t\t3.\n";showTata();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showVolvo();
                            setVolvo_Driver();break;
                        case 2:
                            showMajestic();
                            setMajestic_Driver();break;
                        case 3:
                            showTata();
                            setTata_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;

            case 4:
                time_9_pm();  // Trucks & Drivers of Friday- 9 pm
                {
                    int enter = 0;
                    while(enter==0)
                    {
                        int Truck_Choose;
                        cout << "\tAvaible Truck- \n\n" << endl;
                        cout << "\t\t1.\n";showDaf();
                        cout << "\t\t2.\n";showIveco();
                        cout << "\t\t3.\n";showReliant_Truck();
                        cout <<"\n\n\t\tEnter- ";
                        cin >> Truck_Choose;
                        fflush(stdin);
                        cout << "\n";

                        if (Truck_Choose > 3)
                        {showWrongInput();}
                        else
                        {enter=1;}

                        switch (Truck_Choose)
                        {
                        case 1:
                            showDaf();
                            setDaf_Driver();break;
                        case 2:
                            showIveco();
                            setIveco_Driver();break;
                        case 3:
                            showReliant_Truck();
                            setReliant_Truck_Driver();break;
                        default:
                            showWrongInput();
                        }
                    }
                }
                break;
            default:
                showWrongInput();
            }
        }
    }
    void showWrongInput()
    {
        cout << "You have pressed wrong input... Please Choose Right Option" << endl;
    }
};

int main()
{
    Platinum_Ion platinum_ion_info;  // Object of Platinum_Ion
    int Option_Choose;

    Trailer_List tralier_info;  // Object of Trailer_List
    int Trailer_List_Choose;

    Route route_info;  // Object of Route
    int Route_Choose;

    Driver driver_info;  // Object of Driver
    int Driver_Choose;

    Truck truck_info;  // Object of Truck
    int Truck_Choose;

    Time time_info;  // Object of Time
    int Time_Choose;

    Truck_Driver_Management truck_driver_info;  // Object of Truck_Driver_Managemen

    Day day_info;  // Object of Day
    int Day_Choose;

    float totalCost;

cout << "       **** *      *  ***** *** *   * *   * *    *     *** ***** **  * " << endl;
cout << "       *  * *     * *   *    *  **  * *   * **  **      *  *   * **  * " << endl;
cout << "       **** *    *****  *    *  * * * *   * * ** * ***  *  *   * * * * " << endl;
cout << "       *    *    *   *  *    *  * * * *   * *    *      *  *   * * * * " << endl;
cout << "       *    *    *   *  *    *  *  ** *   * *    *      *  *   * *  ** " << endl;
cout << "       *    **** *   *  *   *** *   * ***** *    *     *** ***** *   * " << endl;
cout << "!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!" << endl;

cout << "\n\n" << endl;
cout << "WELCOME TO ***PLATINUM-ION TRAILER SERVICE-DHAKA***" << endl;

for(int i =0 ; ; i++)
{
// Menu & Option Choosing
MENU:
cout << "\n\n\n" << endl;
cout << "^^^^^^^^^^^^^^^^^^^^^^^^^^^^" << endl;
cout << "Choose Option From The List: " << endl;
cout << "(Press 0,1,2,3,4,5,6,7 Enter for selection)\n\n" << endl;

cout << "1. About Platinum-Ion." << endl;
cout << "2. Approved Trailer (include charge)." << endl;
cout << "3. Drivers Information." << endl;
cout << "4. Available Trucks(include charge)." << endl;
cout << "5. Time Chart of Truck's Departure." << endl;
cout << "6. Route Information (include length.)" << endl;
cout << "7. Rent a truck for your trailer." << endl;
cout << "0. Exit" << endl;

cout << "\nEnter your option from the menu>>> ";
cin >> Option_Choose;
cout << "\n" << endl;

if(Option_Choose == 0)
{
    cout << "!!!Thanks a lot to visit our Company!!!" << endl;
    return 0;
}
if(Option_Choose > 7)
{
    cout <<"You have chosen wrong information, please select correct option.\n" << endl;
    goto MENU;
}

switch(Option_Choose)
{
case 1:
    cout << platinum_ion_info;  // Information about Platinum_Ion
    break;
case 2:
    tralier_info.showTrailerList();  // Showing Trailer List
    break;
case 3:
    driver_info.show_Drivers_Full_Profile();  // Showing All Drivers Information In One Function
    break;
case 4:
    truck_info.showTruckList();  // Showing Trucks List
    break;
case 5:
    day_info.showTimeList();  // Showing Time List
    break;
case 6:
    route_info.showRouteList();  // Showing Routes List
    break;
case 7:
    {
    char customerName[NameLength];
    char receiverName[NameLength];
    char customerAddress[AddressLength];
    int  customerContactNumber;
    int  receiverContactNumber;

    int enter=0;
    while(enter==0)
    {
        cout << "\n\nTo rent a truck you must provide us this information\n\n\n" << endl;
        cout << "################################" << endl;
        cout << "\n" << endl;
        cout << "Your Nane: ";cin >> customerName;fflush(stdin);  // Inputing Customer Name
        cout << "Receiver Nane: ";cin >> receiverName;fflush(stdin);  // Inputing Receiver Name
        cout << "Your Address(press $ to complete input): ";cin.get(customerAddress, AddressLength, '$');fflush(stdin);  // Inputing Receiver Name
        cout << "Your Contact Number: ";cin >> customerContactNumber;fflush(stdin);  // Inputing Customer Contact Number
        cout << "Your Receiver's Contact Number: ";cin >> receiverContactNumber;fflush(stdin);  // Inputing Receiver Contact Number
        cout << "\n" << endl;
        cout << "################################" << endl;

        cout << "\n\nMr. " << customerName <<" Choose Your Trailer Type From The List(Enter 0 for returning main menu)\n" << endl;
        tralier_info.showTrailerList();
        cout << "\n" << endl;
        cout <<"Enter- ";
        cin >> Trailer_List_Choose;
        fflush(stdin);
        cout << "\n";
        if(Trailer_List_Choose == 0)
        {
            cout << "You are returning to main menu\n" << endl;
            goto MENU;
        }

        if (Trailer_List_Choose > 34)
        {tralier_info.showWrongInput();}
        else{enter=1;}
    }

    switch (Trailer_List_Choose)  // Choosing Trailer from List
    {
    case 1:
        tralier_info.showAmmunition();break;
    case 2:
        tralier_info.showBamboo();break;
    case 3:
        tralier_info.showCement();break;
    case 4:
        tralier_info.showChemical();break;
    case 5:
        tralier_info.showCloth();break;
    case 6:
        tralier_info.showCoal();break;
    case 7:
        tralier_info.showCrops();break;
    case 8:
        tralier_info.showDigger();break;
    case 9:
        tralier_info.showDry_Milk();break;
    case 10:
        tralier_info.showElectronics_Parts();break;
    case 11:
        tralier_info.showExcavator();break;
    case 12:
        tralier_info.showFish();break;
    case 13:
        tralier_info.showFlowers();break;
    case 14:
        tralier_info.showFood();break;
    case 15:
        tralier_info.showFrozen_Food();break;
    case 16:
        tralier_info.showFruits();break;
    case 17:
        tralier_info.showFurniture();break;
    case 18:
        tralier_info.showGas();break;
    case 19:
        tralier_info.showGlass();break;
    case 20:
        tralier_info.showIce_Cream();break;
    case 21:
        tralier_info.showIron();break;
    case 22:
        tralier_info.showLiquid_Oxygen();break;
    case 23:
        tralier_info.showMeat();break;
    case 24:
        tralier_info.showMedical_Accessories();break;
    case 25:
        tralier_info.showMetal();break;
    case 26:
        tralier_info.showOil();break;
    case 27:
        tralier_info.showPetroleum();break;
    case 28:
        tralier_info.showRock();break;
    case 29:
        tralier_info.showSand();break;
    case 30:
        tralier_info.showSpices();break;
    case 31:
        tralier_info.showTractor();break;
    case 32:
        tralier_info.showVegetables();break;
    case 33:
        tralier_info.showWater();break;
    case 34:
        tralier_info.showWood();break;
    default:
        tralier_info.showWrongInput();
    }
    cout << "\n\n" << endl;

    enter = 0;
    while(enter==0)
    {
        cout << "\nSelect your route from the list(Enter 0 for returning main menu)\n" << customerName << endl;
        route_info.showRouteList();
        cout << "\n" << endl;
        cout <<"Enter- ";
        cin >> Route_Choose;
        fflush(stdin);
        cout << "\n";

        if(Route_Choose == 0)
        {
            cout << "You are returning to main menu\n" << endl;
            goto MENU;
        }

        if (Route_Choose > 63)
        {route_info.showWrongInput();}
        else{enter=1;}
    }

    switch (Route_Choose)  // Choosing Route from List
    {
    case 1:
        route_info.route_Dh_to_Brgrht();break;
    case 2:
        route_info.route_Dh_to_Bndrbn();break;
    case 3:
        route_info.route_Dh_to_Brgn();break;
    case 4:
        route_info.route_Dh_to_Brshl();break;
    case 5:
        route_info.route_Dh_to_Brnmnbr();break;
    case 6:
        route_info.route_Dh_to_Bhl();break;
    case 7:
        route_info.route_Dh_to_Bgr();break;
    case 8:
        route_info.route_Dh_to_Chndpr();break;
    case 9:
        route_info.route_Dh_to_Chttgng();break;
    case 10:
        route_info.route_Dh_to_Chdng();break;
    case 11:
        route_info.route_Dh_to_Cmll();break;
    case 12:
        route_info.route_Dh_to_Cxbzr();break;
    case 13:
        route_info.route_Dh_to_Dnjpr();break;
    case 14:
        route_info.route_Dh_to_Frdpr();break;
    case 15:
        route_info.route_Dh_to_Fn();break;
    case 16:
        route_info.route_Dh_to_Gnbndh();break;
    case 17:
        route_info.route_Dh_to_Gzpr();break;
    case 18:
        route_info.route_Dh_to_Gplgnj();break;
    case 19:
        route_info.route_Dh_to_Hbgnj();break;
    case 20:
        route_info.route_Dh_to_Jprht();break;
    case 21:
        route_info.route_Dh_to_Jmlpr();break;
    case 22:
        route_info.route_Dh_to_Jssr();break;
    case 23:
        route_info.route_Dh_to_Jhlkth();break;
    case 24:
        route_info.route_Dh_to_Jhndh();break;
    case 25:
        route_info.route_Dh_to_Khgrchr();break;
    case 26:
        route_info.route_Dh_to_Khln();break;
    case 27:
        route_info.route_Dh_to_Kshrgnj();break;
    case 28:
        route_info.route_Dh_to_Krgrm();break;
    case 29:
        route_info.route_Dh_to_Ksht();break;
    case 30:
        route_info.route_Dh_to_Lkshmpr();break;
    case 31:
        route_info.route_Dh_to_Llmnrht();break;
    case 32:
        route_info.route_Dh_to_Mdrpr();break;
    case 33:
        route_info.route_Dh_to_Mgr();break;
    case 34:
        route_info.route_Dh_to_Mnkgnj();break;
    case 35:
        route_info.route_Dh_to_Mhrpr();break;
    case 36:
        route_info.route_Dh_to_Mulvbzr();break;
    case 37:
        route_info.route_Dh_to_Mnshgnj();break;
    case 38:
        route_info.route_Dh_to_Mymnsngh();break;
    case 39:
        route_info.route_Dh_to_Ngn();break;
    case 40:
        route_info.route_Dh_to_Nryngn();break;
    case 41:
        route_info.route_Dh_to_Nrsngd();break;
    case 42:
        route_info.route_Dh_to_Ntr();break;
    case 43:
        route_info.route_Dh_to_Nwbgnj();break;
    case 44:
        route_info.route_Dh_to_Ntrkn();break;
    case 45:
        route_info.route_Dh_to_Nlphmar();break;
    case 46:
        route_info.route_Dh_to_Nkhl();break;
    case 47:
        route_info.route_Dh_to_Nrl();break;
    case 48:
        route_info.route_Dh_to_Pbn();break;
    case 49:
        route_info.route_Dh_to_Pnchgrh();break;
    case 50:
        route_info.route_Dh_to_Ptkhl();break;
    case 51:
        route_info.route_Dh_to_Prjpr();break;
    case 52:
        route_info.route_Dh_to_Rjbr();break;
    case 53:
        route_info.route_Dh_to_Rjshh();break;
    case 54:
        route_info.route_Dh_to_Rngmt();break;
    case 55:
        route_info.route_Dh_to_Rngpr();break;
    case 56:
        route_info.route_Dh_to_Stkhr();break;
    case 57:
        route_info.route_Dh_to_Shrytpr();break;
    case 58:
        route_info.route_Dh_to_Shrpr();break;
    case 59:
        route_info.route_Dh_to_Srjgnj();break;
    case 60:
        route_info.route_Dh_to_Snmgnj();break;
    case 61:
        route_info.route_Dh_to_Sylht();break;
    case 62:
        route_info.route_Dh_to_Tngl();break;
    case 63:
        route_info.route_Dh_to_Thkrgn();break;
    default:
        route_info.showWrongInput();
    }
    cout << "\n\n" << endl;

    enter = 0;
    while(enter==0)
    {
        cout << "\nSelect your day from the list(Enter 0 for returning main menu)\n" << endl;
        day_info.showDayList();
        cout << "\n" << endl;
        cout <<"Enter- ";
        cin >> Day_Choose;
        fflush(stdin);
        cout << "\n";

        if(Day_Choose == 0)
        {
            cout << "You are returning to main menu\n" << endl;
            goto MENU;
        }

        if (Day_Choose > 7)
        {day_info.showWrongInput();}
        else{enter=1;}
    }

    switch (Day_Choose)  // Choosing Day from List
    {
    case 1:
        day_info.Saturday();break;
    case 2:
        day_info.Sunday();break;
    case 3:
        day_info.Monday();break;
    case 4:
        day_info.Tuesday();break;
    case 5:
        day_info.Wednesday();break;
    case 6:
        day_info.Thursday();break;
    case 7:
        day_info.Friday();break;
    default:
        day_info.showWrongInput();
    }
    cout << "\n\n" << endl;

    totalCost =  tralier_info.getTrailerPrice() * route_info.getRoutePrice() * day_info.getTruckServiceCharge() + (route_info.getRoutePrice() * day_info.getDriverServiceCharge());

    cout << ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" << endl;
    cout << "\n\n";
    cout << "YOUR TOTAL COST: " << totalCost << " Tk\n\n" << endl;

    TRANSECTION:  // Transsection Calculating
		cout << "Mr. "<< customerName <<" are  you want to give Advance amount ?"  << endl;
		cout << "Press 'Y'/'y' for yes or 'N'/'n' for no" << endl;
		float Cash;
		char Selection;
		cout << "Enter: ";
		cin >> Selection;
		fflush(stdin);
		if(Selection != 'Y' && Selection != 'y' && Selection != 'N' && Selection != 'n')
        {
            cout << "\nWront Input !!! Please provide right selection \n"  << endl;
            goto TRANSECTION;
        }
		else if(Selection == 'Y' || Selection == 'y')
        {
            cout << "\nHow mush amount you want to give advance ?" << endl;
            cout << "Please Enter:-  ";
            cin >> Cash;
            if (Cash > totalCost)
            {
                cout << "\nYou have entered wrong amount of money." << endl;
                cout << "So confirm us again\n." << endl;
                goto TRANSECTION;
            }
            else if(Cash == totalCost)
            {
                cout << "\nThanks a lot Mr. " << customerName <<" for paying full amount." << endl;
                cout << "Receiver Mr. " << receiverContactNumber <<" have not need to pay." << endl;
                cout << "Best of luck !!!" << endl;
                cout << "`````````````````````````````````````````````````````````````````" << endl;
            }
            else if(Cash < totalCost)
            {
                cout << "\nThanks Mr. " << customerName <<" to pay advance amount." << endl;
                totalCost = totalCost - Cash;
                cout << "Receiver Mr. "<< receiverName <<" have to pay " << totalCost << " tk after arrival." << endl;
                cout << "Hope you all the best !!!" << endl;
                cout << "`````````````````````````````````````````````````````````````````" << endl;
            }
        }
        else if(Selection == 'N' || Selection == 'n')
		{
			cout << "\nYou have decided that you may not pay any cash." << endl;
			cout << "So receiver Mr. "<< receiverName <<" have to pay.-" << totalCost << " tk after arrival" << endl;
			cout << "`````````````````````````````````````````````````````````````````" << endl;
		}
    cout << "\n\n";
    return 0;
    }
    break;
default:
    cout << "You have pressed wrong input... Please Choose Right Option\n\n" << endl;
    goto MENU;

    cout << "\n\n" << endl;
    fflush(stdin);
    getchar();
    return 0;
}
}
}

